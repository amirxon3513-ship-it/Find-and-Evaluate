# Find and Evaluate (FaE)

A hands-first VR / MR evidence room for researchers and students. Every statement in your notes gets an integer context score **K** from its sources. Pinch a source onto a claim and watch its truth change.

Built for the Meta VR Start Developer Competition 2026 (Productivity & Tools).

## How it works
- **K** is the sum of source weights; each source name counts once: official +3, peer-reviewed +2, internal +2, external +1, rumor 0, outdated −2, known false −3.
- **K ≥ 1** verified (T), **K = 0** unverified (U), **K ≤ −1** refuted (F). Only verified statements reach an answer.
- Self-referential statements are quarantined at K = 0 (Axiom 4) instead of looping.
- If the room has no match, FaE searches peer-reviewed literature (OpenAlex) and adds what it finds to the room.
- The engine is based on Contextual Logic (Kappa Gate), our own framework.

## Hands-first VR / MR
Open the site in Meta Quest Browser and press **Enter VR · hands** or **Mixed reality**. Seated, within arm's reach:
- poke a question, a button or an orb to select it
- pinch a source token and release it over an orb to attach the source
- controllers work as a fallback

Without a headset, press **3D preview** to look around with the mouse, or **60-second tour** for a guided walk-through.

## Run locally
It is a single static file. Open `index.html`, or serve the folder over HTTPS for WebXR.

## Tech
Raw WebXR + WebGL2 (hand-tracking joints), Canvas 2D, Web Audio. No build step, no dependencies.
